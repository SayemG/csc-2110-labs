#include <iostream>
#include <string>
#include<fstream>

using namespace std;
#define ASIZE 8

void insertionSort(int vote[], string name[], int listLength)
{
	//complete me

	int firstOutOfOrder, location;
	int tempV;
	string tempN;
	for (firstOutOfOrder = 1; firstOutOfOrder < listLength; firstOutOfOrder++)
	{
		if (vote[firstOutOfOrder] < vote[firstOutOfOrder - 1])
		{
			tempV = vote[firstOutOfOrder];
			tempN = name[firstOutOfOrder];
			location = firstOutOfOrder;
			do
			{
				vote[location] = vote[location - 1];
				name[location] = name[location - 1];
				location--;
			} while (location > 0 && vote[location - 1]>tempV);
			vote[location] = tempV;
			name[location] = tempN;
		}

	}
}

string binarySearch(const int vote[], const string name[], int listLength, int searchItem)
{
	//complete me
	int first = 0;
	int last = listLength - 1;
	int mid;
	bool found = false;
	while (first <= last&& !found)
	{
		mid = (first + last) / 2;

		if (searchItem == vote[mid])
		found =true;
		else if (vote[mid] > searchItem)
			last = mid - 1;
		else if (searchItem > vote[mid])
			first = mid + 1;
	}
	if (found)
		return name[mid];
	else
	return "There is no candidate with the inputed votes";

}

int main() {
	ifstream inData;
	string name[ASIZE];
	int vote[ASIZE];

	inData.open("input.dat");
		if (!inData)
		{
			cout << "Failed to open the File!" << endl;

		}
		else if (inData)
		{
			while (!inData.eof())
			{
				for (int i = 0; i < ASIZE; i++)
				{
					inData >> name[i];
					inData >> vote[i];
				}
			}
		}


	//read your input from input.txt here



	//Part1
	insertionSort(vote, name, ASIZE);
	cout << "Candidate\t" << "Votes Received\t" << endl;

	for (int i = 0; i<ASIZE; i++){
		cout << name[i] << "\t\t" << vote[i] << endl;
	}

	cout << "The winner of the election is " << name[ASIZE - 1] << endl;

	//Part2
	cout << "Please enter the vote number to be searched?\n";
	int x;
	cin >> x;
	cout << binarySearch(vote, name, ASIZE, x) << endl;
	return 0;
}