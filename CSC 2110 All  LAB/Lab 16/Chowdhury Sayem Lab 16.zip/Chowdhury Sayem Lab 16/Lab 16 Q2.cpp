#include<iostream>
#include<string>
using namespace std;


template <class C>
class Rectangle {
public:
	Rectangle(float length = 0, float width = 0)
	{
		len = length;
		wid = width;
	}

	void set(float length, float width)
	{
		len = length;
		wid = width;


		cout << "Enter the length and width for a rectangle: " << endl;
		cin >> len >> wid;
	}

	void get(float &length, float &width)

	{
		length = len;
		width = wid;
	}

	string getType() // Returns �RECTANGLE� 
	{
		return " RECTANGLE";
	}

	float area()
	{
		//cout<<"Area of a Rectangle ";
		return (len*wid);
	}

	template <class C>
	float maxFill(C &other)
	{
		return area() / other.area();
	}

private:
	float len, wid;
};



template<class D>
class Triangle {
public:
	Triangle(float base = 0, float height = 0)
	{
		b = base;
		h = height;

	}
	void set(float base, float height)

	{
		h = height;
		b = base;

		cout << "Enter the base and height for a triangle: " << endl;
		cin >> b >> h;
	}
	void get(float &base, float &height)
	{
		base = b;
		height = h;
	}
	string getType() // Returns �TRIANGLE�
	{
		return "TRIANGLE";

	}
	float area()
	{
		return (.5*b*h);
	}

	template <class D>
	float maxFill(D &other)
		
	{
		return area() / other.area();
	}
	
private:
	float b, h;
};
////
template<class C>
void  display(C obj);

template<class C, class D>
bool equalArea(C obj1, D obj2);
/////
int main()
{

	Triangle <float> T1;
	Rectangle <float> R1;
	T1.set(1.0, 2.0);
	R1.set(1.0, 2.0);
	display(R1);
	display(T1);


	if (equalArea(R1, T1))
	{
		cout << "The two objects are of equal area" << endl;
	}
	else
	{
		cout << "The two objects are of unequal area" << endl;
	}

	//
   cout<<"There are "<<R1.maxFill(T1)<<" triangles that will fit in the rectangle"<<endl;
   cout<<"There are "<<T1.maxFill(R1)<<" rectangles that will fit in the triangle"<<endl;
   cout<<"There are "<<R1.maxFill(R1)<<" rectangles that will fit into the rectangle"<<endl;
	//
	return 0;
}


/*
* Produces the output:
* Area of a <TYPE> is <AREA>
*/
template<class C>
void  display(C obj)
{
	cout << "Area of a " << obj.getType() << " is " << obj.area() << endl;
}

/*
* Returns true if the area of obj1 and obj2 are equal,
* false otherwise.
*/
template<class C, class D>
bool equalArea(C obj1, D obj2)
{
	if (obj1.area() == obj2.area())
		return true;
	else
		return false; 
}