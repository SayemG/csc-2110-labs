
#include"MemberType.h"
#include<iostream>
#include<string>

using namespace std;

/*MemberType::MemberType()
{
	name = "Jhon";
	memberID = 100;
	noOfbook = 1;
}*/
void MemberType::print_member() const
{
	
	cout << "Name of the person: " << name << "  member ID: " << memberID << "  no of books bought " << noOfbook << endl;
} 
void MemberType::set_new_member(string abc, int a, int b)
{
	
	name = abc;
	memberID = a;
	noOfbook = b;

}
void MemberType::modify_name()
{
	
	getline(cin,name);
}


void  MemberType::modify_member_id()
{
	
	cin >> memberID;

}
void MemberType::modify_no_books()
{
	
	cin >> noOfbook;
	cout << endl;
}


void MemberType::show_Modify_name()const
{
	cout << "Updated name: " << name << endl;
}

void MemberType::show_modify_member_id()const
{
	cout <<"Updated ID : "<< memberID << endl;
}

void MemberType::show_modify_books()const
{
	cout << "Updated number of books bought: " << noOfbook << endl;
}

