#include<iostream>
#include<string>
using namespace std;
class MemberType
{
public:
    void set_new_member(string, int, int);
	void print_member()const;
	void modify_name();
	void show_Modify_name()const;
	void  modify_member_id();
	void show_modify_member_id() const;
	void modify_no_books();
	void show_modify_books()const;
	//MemberType();
private:
	string name= "Jhon";  
	int memberID = 100;
	int noOfbook=1;
};
