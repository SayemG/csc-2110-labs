
#include"MemberType.h"

#include<iostream>
#include<string>
using namespace std;



int main()
{
	MemberType person1;
	MemberType person2;

	cout << "Member1: Initialized using the constructor function" << endl;
	person1.print_member();
	cout << endl << endl;

	cout << "Member 2: Created a new member using utility function of the class" << endl;
	person2.set_new_member("Robert De", 200, 2);
	person2.print_member();
	cout << endl << endl;

	cout << "Modify name for member 2: ";
	person2.modify_name();
	cout << "Modify member ID for member 2: ";
    person2.modify_member_id();
	cout << "Modify number of books bought for member 2: ";
	person2.modify_no_books();

	person2.show_Modify_name();
	person2.show_modify_member_id();
	person2.show_modify_books();

	return 0; 
}