//The user program that uses the class clockType
   
#include <iostream>
#include "clockType.h"
 
using namespace std; 

int main()
{
    clockType myClock;

    int hours;
    int minutes;
    int seconds;

        //Set the time of myClock
    myClock.setHours(5);   
	myClock.setMinutes(4);
	myClock.setSeconds(30);


                        
    myClock.printTime();  //print the time of myClock   
    cout << endl;                
	// Set the time of myClock using the value of the
	//variables hours, minutes, and seconds
	cout << "update Hours:";
	cin >> hours;            
    cout << endl;  

    myClock.setHours(hours);    //function will set the value of hours to hr
    myClock.printHrMin();   //print the time of myClock without seconds
    cout << endl;   
	
	cout << "update Minutes:";
	cin >> minutes;                
	cout << endl;  
   
	myClock.setMinutes(minutes);
    myClock.printHrMin();  
    cout << endl; 

	cout << "update Seconds:";
	cin >> seconds;
	cout << endl;  

	myClock.setSeconds(seconds); 
	myClock.printTime();   
	cout << endl;

    return 0;
}
//////////////////////