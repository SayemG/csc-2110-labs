//clockType.h, the specification file for the class clockType
#include<iostream>
using namespace std;
class clockType
{
public:
    void setHours(int hours);
	void setMinutes(int minutes);
	void setSeconds(int seconds);

	int getHours()   const;
	int getMinutes() const;
	int getSeconds()  const;
      
    void printTime() const;
	void printHrMin() const;
    
    clockType(int hours, int minutes, int seconds);
    clockType();
      
private:
    int hr;  //variable to store the hours
    int min; //variable to store the minutes
    int sec; //variable to store the seconds
};
