
/* Sayem Chowdhury// lab02//
Write a program that uses for loop performing the following steps:
A. Prompt the user to input two integers: firstNum and secondNum
(firstNum must be less than secondNum).
B. Output the numbers between (inclusive) firstNum and secondNum.
C. Output the sum of the numbers between (inclusive) firstNum and secondNum.
D. Output all odd numbers between (exclusive) firstNum and secondNum.
*/
#include<iostream>
#include<string>
using namespace std;
int main()
{
	int First_num, Second_num,sum;
	int counter = 0;
	sum = 0; 
	//part(a)
	for (int s = 0; s < 1; s++) //need just single iteration for input from the user
	{
		cout << "Please Enter two spaced seperated numbers: ";
		cin >> First_num; cin >> Second_num; 

		if (First_num>Second_num)//
		{
			cout << "The second number must be greater than first number " << endl;//prompt line for user input
			return-1;
		}
	}
	//part(b) and part (c)
	int j = First_num;
	int k = Second_num;

	for (int m = First_num; m <= Second_num; m++)
	{
		cout << First_num;
		cout << " ";
		sum += First_num;
		First_num += 1;
	}

	cout << endl;
	cout << "sum is:" << sum << endl;
	//cout << First_num << " " << Second_num << endl;
	//part(d) printing odd numbers between First_num and Second_num
	if (j % 2 == 0)
	{
		counter = j + 1;
	}
	else
	{
		counter = j + 2;
	}

	for (j = counter; j < k; j=j+2)//incrementing counter and lcv by 2 
	{
		cout <<counter << " ";
		counter += 2; 

		/*Other way
		cout j;
		*/
	}

	return 0;

}