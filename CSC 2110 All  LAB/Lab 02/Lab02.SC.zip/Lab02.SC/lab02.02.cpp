/*
sayem chowdhury//lab//02
Write a program that uses while loops performing the following steps:
A. Prompt the user to input two integers: firstNum and secondNum
(firstNum must be less than secondNum).
B. Output the numbers between (inclusive) firstNum and secondNum.
C. Output the sum of the numbers between (inclusive) firstNum and secondNum.
D. Output all odd numbers between (exclusive) firstNum and secondNum
Match the output of the examples below:
Example 1:
Enter two space separated numbers: 5 13
5 6 7 8 9 10 11 12 13
Sum is: 81
7 9 11
*/
#include<iostream> //Header files
#include<string>
using namespace std; 
int main()
{
	int sum = 0;
	int counter = 0;
	
	//part(a)
	int First_num, Second_num; //loop control variable
	First_num = 10; //initialize to 10
	Second_num = 7;

	while (!(First_num<Second_num))  // making loop condition true 
	{
		cout << "Please Enter two spaced seperated numbers: "; //prompt line for user input
		cin >> First_num>>Second_num;
		
		if ( First_num>Second_num)
		{
			cout << "The second number must be greater than first number " << endl;
			return-1; // will exit from the programm
		}
	}
	int temp1 = First_num; // saving the value First_num for later use 
	int temp2 = Second_num;

	//part(b) and Part (c)
	while (First_num <= Second_num)
	{
		cout << First_num ;
		cout << " ";
		sum += First_num;
		First_num += 1;
	}

	cout << endl;
	cout << "sum is:" << sum << endl;
	//part(d)

	if (temp1 % 2 == 0)//condition for finding First_num odd or even
	{
		counter = temp1 + 1;//when First number is even
	}
	else
	{
		counter =temp1+ 2; //when first number is odd (exclusive) finding next odd number
	}

	while (counter < temp2)// exclusive first and second number
	{
		cout << counter<< " ";
		counter += 2;
	}
	cout << endl;
	return 0;
}