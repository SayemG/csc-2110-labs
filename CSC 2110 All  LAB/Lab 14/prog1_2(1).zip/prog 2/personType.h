
   
#include <string> 

using namespace std;

class personType
{
public:
    virtual void print() const;
       
  
    void setName(string first, string last);
      

    string getFirstName() const;
      

    string getLastName() const;
     

    personType(string first = "", string last = "");
        

 protected:
    string firstName; 
    string lastName;  
};

