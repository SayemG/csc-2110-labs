#include "extPersonType.h"
#include <iostream>

int main()
{	

	extPersonType myPerson = extPersonType("John", "Denver", 3 , addressType(" 42 W Warren Ave", "Wayne", "MI", "48202"));

	myPerson.print();	
	
	system("pause");
}

