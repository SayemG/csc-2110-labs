#ifndef dateType_H
#define dateType_H 
   
class dateType
{
public:
	// check the format of month, day and year. 
	// if the format is incorrect, displays a message and returns false
	// if the format is correct, returns true
    bool setDate(int month, int day, int year);
    
	//determines whether its a leap year or not
	bool isLeapYear() const;
	
	// returns current day
    int getDay() const;
     
	// returns current month
    int getMonth() const;
      
	// returns current year
    int getYear() const;
      
	// prints the current date
    void printDate() const;
      

    dateType();
     

private:
    int dMonth; 
    int dDay;   
    int dYear;  
};

#endif