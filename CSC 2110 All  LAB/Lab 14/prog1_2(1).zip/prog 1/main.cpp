#include <iostream>
#include "dateType.h"
using namespace std;

int main()
{
	int Month, Day, Year;

	while (true)
	{
		Month = 0; Day = 0; Year = 0;

		cout << "Month: ";
		cin >> Month;
		cout << "Day: " ;
		cin >> Day;
		cout << "Year: ";
		cin >> Year;

		dateType dt;
		if (dt.setDate(Month, Day, Year)){
			dt.printDate();
			cout << endl << "Leap year = " << dt.isLeapYear() << endl;
			break;
		}
		else
			cout << endl<<"Please enter proper date format"<<endl;		
	}

	return 0;
}

