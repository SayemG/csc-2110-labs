#include"Day.h"
#include<iostream>
#include<string>
using namespace std;

Day::Day()
{
	_day = " SUN";
}

Day::Day(string day)
{
	_day = "THU";
}

void Day::setDay(string day)
{
	_day = day;
}


string Day::getDay()
{
	return _day;
}

string Day::getStr(int idx)
{
	string all_Days[] = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
	return all_Days[idx];
}
int Day::getIdx(string day)
{
	string days_in_week[] = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
	for (int n = 0; n < 7; n++)
		if (day == days_in_week[n])
			return n;
	return -6;
}

void Day::addDays(int numDays)
{
	numDays = (numDays % 7);
	for (int o = 0; o < numDays; o++)
		_day = nextDay();
}
string Day::nextDay()
{
	int next_Day = getIdx(_day);
	if (next_Day == 6)
		return getStr(0);
	else
	     return getStr(next_Day + 1);
}
string Day::prevDay()
{
	int previous_Day = getIdx(_day);
	if (previous_Day == 0)
		return getStr(6);
	else
	    return getStr(previous_Day - 1);
}

