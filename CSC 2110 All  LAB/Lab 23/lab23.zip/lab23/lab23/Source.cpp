#include<iostream>
using namespace std;

typedef struct node
{
	int data;
	node *next;
};

node *insertBegin(node *current_head)
{
	node* newnode = new node;
	cout << "Please enter the number: ";
	cin >> newnode->data;
	newnode->next = current_head;
	cout << "Number inserted into the list.\n";
	return newnode;
}


node *insertEnd(node *head)
{
	int data;
	cout << "please enter the number";
	cin >> data;
	node * newND = new node;
	newND->data = data;
	newND->next = NULL;
	if (head == NULL)
	{
		return newND;
	}
	else
	{
		node *tem = head;
		while (tem->next != NULL){
			tem = tem->next;
		}

		tem->next = newND;
		return head;
	}

}
void printList(node *head)
{
	cout << "\nList: ";
	while (head != NULL)
	{
		cout << head->data << " ";
		head = head->next;
	}
	cout << endl;

}
void showMenu(){
	cout << "1:Add a number in the end." << endl;
	cout << "2:print list:" << endl;
	cout << "3: Quit" << endl;
	cout << "plwase enter a choice" << endl;
}

int main()
{
	node *head = NULL;
	int input;
	while (true) {
		showMenu();
		cin >> input;
		switch (input){
		case 1:
			head = insertEnd(head);
			break;
		case 2:
			printList(head);
			break;
		case 3: return 0;
			break;
		default:  cout << endl;
		}
		cout << endl;
	}
	return 0;
}