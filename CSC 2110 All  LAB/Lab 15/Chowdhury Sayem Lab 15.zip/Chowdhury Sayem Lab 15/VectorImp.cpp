#include "Vector.h"
#include<iostream>
using namespace std;


Vector::Vector()
{
	x = 0.0;
	y = 0.0;
}


Vector::Vector(float a, float b)
{
	x = a;
	y = b;
}

float Vector:: getX() const
{
	return x;
}



float Vector::getY() const
{
	return y;
}

Vector Vector::operator+(const Vector &other) const
{
	Vector tempt;
	tempt.x = x + other.x;
	tempt.y = y + other.y;
	return tempt;

} 

Vector Vector::operator-(const Vector &other) const
{
	Vector tempt;
	tempt.x = x - other.x;
	tempt.y = y - other.y;
	return tempt;

}

ostream& operator<<(ostream& os, const Vector &v)
{
	os <<"("<< v.x << "," << v.y<<")";
	return os;


}

